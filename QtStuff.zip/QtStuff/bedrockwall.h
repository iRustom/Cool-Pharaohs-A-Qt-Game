#ifndef BEDROCKWALL_H
#define BEDROCKWALL_H

#include <QGraphicsPixmapItem>

class BedrockWall: public QGraphicsPixmapItem
{
public:
    BedrockWall(QGraphicsItem * parent=0);
};

#endif // BEDROCKWALL_H
