#ifndef MENU_H
#define MENU_H
#include <QDialog>

class Menu : public QDialog
{
    Q_OBJECT
public:
    Menu(QWidget * parent =  nullptr);
private:
    QDialog


};

#endif // MENU_H
