#include "menu.h"

Menu::Menu(): QMainWindow()
{


}
