#ifndef PUDDLE_H
#define PUDDLE_H
#include <QGraphicsPixmapItem>

class Puddle : public QGraphicsPixmapItem
{
public:
    Puddle(QGraphicsItem * parent=0);
};

#endif // PUDDLE_H
