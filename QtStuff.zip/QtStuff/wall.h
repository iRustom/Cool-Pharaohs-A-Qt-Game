#ifndef WALL_H
#define WALL_H

#include <QGraphicsPixmapItem>

class Wall: public QGraphicsPixmapItem
{
public:
    Wall(QGraphicsItem * parent=0);
};

#endif // WALL_H
